package com.acme.leavemgmt.servlet.auth;

import com.acme.leavemgmt.dao.SysSettingDAO;
import com.acme.leavemgmt.dao.SysSettingDAO.GoogleConfig;
import com.acme.leavemgmt.dao.UserDAO;
import com.acme.leavemgmt.model.User;
import com.acme.leavemgmt.util.DBConnection;
import com.acme.leavemgmt.util.GoogleOAuthHelper;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.Instant;
import java.util.Base64;
import java.util.Map;

@WebServlet(urlPatterns = {"/oauth/google/*"})
public class GoogleOAuthServlet extends HttpServlet {

    private static final SecureRandom RNG = new SecureRandom();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException {

        String pi = req.getPathInfo();
        if (pi == null || "/start".equals(pi)) {
            start(req, resp);
            return;
        }
        if ("/callback".equals(pi)) {
            callback(req, resp);
            return;
        }
        resp.sendError(404);
    }

    /* =================== /oauth/google/start =================== */
    private void start(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException {
        try (Connection cn = DBConnection.getConnection()) { // dùng Connection, KHÔNG phải DataSource
            SysSettingDAO sdao = new SysSettingDAO(cn);
            GoogleConfig cfg = sdao.loadGoogleConfig(
                    req.getContextPath(), req.getScheme(), req.getServerName(), req.getServerPort());

            if (!cfg.enabled) {
                back(req, resp, "Đăng nhập Google đang tắt.");
                return;
            }

            HttpSession s = req.getSession(true);
            String state = rnd();
            String nonce = rnd(); // hiện chưa gửi lên Google, ta gắn vào session để có thể dùng sau
            s.setAttribute("OAUTH_STATE", state);
            s.setAttribute("OAUTH_NONCE", nonce);

            // GoogleOAuthHelper bản hiện tại đã có buildAuthUrl(state)
            String authUrl = GoogleOAuthHelper.buildAuthUrl(state);

            resp.sendRedirect(authUrl);
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    /* =================== /oauth/google/callback =================== */
    private void callback(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException {
        HttpSession s = req.getSession(false);
        String expected = (s == null) ? null : (String) s.getAttribute("OAUTH_STATE");

        String state = req.getParameter("state");
        String code  = req.getParameter("code");
        String error = req.getParameter("error");

        if (error != null) { back(req, resp, "Google từ chối: " + error); return; }
        if (expected == null || !expected.equals(state)) { back(req, resp, "Phiên đăng nhập không hợp lệ."); return; }
        if (code == null || code.isBlank()) { back(req, resp, "Thiếu mã đăng nhập."); return; }

        try (Connection cn = DBConnection.getConnection()) {
            SysSettingDAO sdao = new SysSettingDAO(cn);
            GoogleConfig cfg = sdao.loadGoogleConfig(
                    req.getContextPath(), req.getScheme(), req.getServerName(), req.getServerPort());

            if (!cfg.enabled) { back(req, resp, "Đăng nhập Google đang tắt."); return; }

            // Đổi code -> token; helper hiện trả Map<String,Object>
            Map<String,Object> token = GoogleOAuthHelper.exchangeCodeForTokens(code);
            String idToken = str(token.get("id_token"));
            if (idToken == null || idToken.isBlank()) { back(req, resp, "Thiếu id_token từ Google."); return; }

            // Giải mã payload (demo – không xác minh chữ ký) để đọc claim
            Map<String,Object> claims = GoogleOAuthHelper.unsafeDecodeIdToken(idToken);

            // Kiểm tra các field quan trọng
            String aud            = str(claims.get("aud"));
            String iss            = str(claims.get("iss"));
            String email          = str(claims.get("email"));
            String emailVerified  = str(claims.getOrDefault("email_verified", "false"));
            String hd             = str(claims.get("hd"));

            if (!cfg.clientId.isBlank() && !cfg.clientId.equals(aud)) {
                back(req, resp, "Ứng dụng không khớp (aud).");
                return;
            }
            if (!"accounts.google.com".equals(iss) && !"https://accounts.google.com".equals(iss)) {
                back(req, resp, "Nhà phát hành token không hợp lệ (iss).");
                return;
            }
            if (!"true".equalsIgnoreCase(emailVerified)) {
                back(req, resp, "Email Google chưa được xác minh.");
                return;
            }
            if (cfg.allowedHd != null && !cfg.allowedHd.isBlank()
                    && (hd == null || !cfg.allowedHd.equalsIgnoreCase(hd))) {
                back(req, resp, "Email không thuộc domain được phép: " + cfg.allowedHd);
                return;
            }

            // Chỉ cho login nếu user đã tồn tại & active
            UserDAO udao = new UserDAO(cn);           // ✅ dùng constructor theo Connection
            User u = udao.findActiveByEmail(email);
            if (u == null) {
                back(req, resp, "Tài khoản Google (" + email + ") chưa có trong hệ thống hoặc đã bị khoá.");
                return;
            }

            // Cập nhật lần đăng nhập & avatar/name nếu có
            udao.updateGoogleLogin(u.getId(), str(claims.get("picture")), str(claims.get("name")));

            // Tạo session đăng nhập
            HttpSession sess = (s != null ? s : req.getSession(true));
            sess.removeAttribute("OAUTH_STATE");
            sess.removeAttribute("OAUTH_NONCE");
            sess.setAttribute("currentUser", u);
            sess.setAttribute("loginAt", Instant.now().toString());

            resp.sendRedirect(req.getContextPath() + "/");
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    /* =================== helpers =================== */
    private static String rnd() {
        byte[] b = new byte[32];
        RNG.nextBytes(b);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(b);
    }

    private void back(HttpServletRequest req, HttpServletResponse resp, String msg) throws IOException {
        req.getSession(true).setAttribute("error", msg);
        resp.sendRedirect(req.getContextPath() + "/login");
    }

    private static String str(Object o) { return o == null ? null : String.valueOf(o); }
}
